package ec.com.efsr.repository;

public interface MovementRepositoryPort {
}
