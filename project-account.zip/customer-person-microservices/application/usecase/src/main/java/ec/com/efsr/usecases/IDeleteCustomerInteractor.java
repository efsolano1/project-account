package ec.com.efsr.usecases;

public interface IDeleteCustomerInteractor {
    void deleteCustomer(String id);
}
