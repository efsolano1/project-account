package ec.com.efsr.usecases;

import ec.com.efsr.models.Customer;

public interface IUpdateCustomerInteractor {
    Customer updateCustomer(Customer customer);
}
