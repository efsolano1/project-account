package ec.com.efsr.usecases;

import ec.com.efsr.models.Customer;

public interface ISaveCustomerInteractor {
    Customer saveCustomer(Customer customer);
}
