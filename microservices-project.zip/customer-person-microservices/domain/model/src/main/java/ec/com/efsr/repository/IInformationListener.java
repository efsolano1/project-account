package ec.com.efsr.repository;

public interface IInformationListener {
    String receiveInformation(String information);
}
