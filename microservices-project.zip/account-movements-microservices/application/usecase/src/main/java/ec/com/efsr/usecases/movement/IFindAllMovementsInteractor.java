package ec.com.efsr.usecases.movement;

import ec.com.efsr.models.Movement;

import java.util.List;

public interface IFindAllMovementsInteractor {
    List<Movement> findAllMovements();
}
