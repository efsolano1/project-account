package ec.com.efsr.usecases.movement;

import ec.com.efsr.models.Movement;

public interface ISaveMovementInteractor {
    Movement saveMovement(Movement movement);
}
