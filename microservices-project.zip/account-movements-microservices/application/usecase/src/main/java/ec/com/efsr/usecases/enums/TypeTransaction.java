package ec.com.efsr.usecases.enums;

public enum TypeTransaction {
    DEPOSITO,
    RETIRO;
}
