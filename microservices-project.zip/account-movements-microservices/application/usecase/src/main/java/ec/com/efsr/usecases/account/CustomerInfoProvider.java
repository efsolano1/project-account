package ec.com.efsr.usecases.account;

public interface CustomerInfoProvider {
    String getCustomerInfo(String idCustomer);
}
