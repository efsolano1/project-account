package ec.com.efsr.usecases.movement;

import ec.com.efsr.models.Movement;

public interface IUpdateMovementInteractor {
    Movement updateMovement(Movement movement);
}
