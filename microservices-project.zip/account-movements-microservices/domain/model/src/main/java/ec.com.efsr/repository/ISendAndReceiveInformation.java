package ec.com.efsr.repository;

public interface ISendAndReceiveInformation {
    String sendAndReceiveInformation(String information);
}