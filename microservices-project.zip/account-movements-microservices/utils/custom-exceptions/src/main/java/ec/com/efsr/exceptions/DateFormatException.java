package ec.com.efsr.exceptions;

public class DateFormatException extends RuntimeException {
    public DateFormatException(String info) {
        super(info);
    }
}
